
Copy and rename the "udesign-woocommerce.pot" file to "udesign-woocommerce-xx_XX.po" where the 'xx' is the
locale code for the language to translate to, and the 'XX' is the 
country code, e.g. for French it would be: "udesign-woocommerce-fr_FR.po"

Edit your "udesign-woocommerce-xx_XX.po" file with an editor like poEdit (http://www.poedit.net/), translate the strings and then save it.
When you save the "udesign-woocommerce-xx_XX.po" file a "udesign-woocommerce-xx_XX.mo" file will be created in this directory so that WordPress and whatever translation plugin
you're using is be able to use it to facilitate the actual translations.

Enjoy!